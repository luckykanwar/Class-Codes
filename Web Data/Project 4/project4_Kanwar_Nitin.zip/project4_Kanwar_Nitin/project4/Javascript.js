function Redirect(){
	window.location = "Register.php"
}

function redirectToMainPage(){
	window.location = "Account.php"
}
