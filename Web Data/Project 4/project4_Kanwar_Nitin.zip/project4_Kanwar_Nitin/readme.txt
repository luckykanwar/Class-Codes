Readme Instructions-

1. Run the cheapbooksSchema.sql in the database
2. The username for my mysql instance is root and the password is backontrack. Please check the username and password and update it to your local instance.
3. The database already has some default data available which can be used for testing as well as new data can be inserted into the tables.
4. The application is intuitive and should be easy to navigate
