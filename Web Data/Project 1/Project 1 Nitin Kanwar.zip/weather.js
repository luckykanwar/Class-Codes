var api_key = "c8aa267cf0326c869d6aa994d7cd0fcf";

function sendRequest () {
    var xhr = new XMLHttpRequest();
   // var method = "artist.getinfo";
    var city = encodeURI(document.getElementById("form-input").value);
    xhr.open("GET", "proxy.php?q="+city+"&appid="+api_key+"&format=json", true);
    xhr.setRequestHeader("Accept","application/json");
    xhr.onreadystatechange = function () {
        if (this.readyState == 4) {
            var json = JSON.parse(this.responseText);
            var weatherTypeId = json.weather[0].id;
            if(weatherTypeId >= 200 && weatherTypeId <=232){
              var weather = "Thunderstorm";
            } 
            if(weatherTypeId >= 300 && weatherTypeId <= 321){
              weather = "Drizzle";
            }
            if(weatherTypeId >= 500 && weatherTypeId <= 531){
              weather = "Rain";
            }
            if(weatherTypeId >= 600 && weatherTypeId <= 622){
              weather = "Snow";
            }
            if(weatherTypeId == 800){
              weather = "Clear";
            }
            if(weatherTypeId >= 801 && weatherTypeId < 900){
              weather = "Cloudy";
            }

            if(weather == "Thunderstorm" || weather == "Drizzle" || weather == "Rain" || weather == "Snow" || weather == "Cloudy")
            {
              var visibility = "Low"; 
            }
            else
            {
              visibility = "High"; 
            }

            var sunrise = new Date(0);
            var sunset = new Date(0);
            sunset.setUTCSeconds(json.sys.sunset);
            sunrise.setUTCSeconds(json.sys.sunset);
      
            document.getElementById("output").innerHTML = "<br>The coordinates of " + city + " are longitude: " + json.coord.lon + ", lattitude: " + json.coord.lat + ". <br>The temperature today is : " + Math.round(json.main.temp - 273.15) + "&#8451; with minimum temperature being : " + Math.round(json.main.temp_min - 273.15) + "&#8451; and maximum temperature being : " + Math.round(json.main.temp_max - 273.15) + "&#8451; <br>" +
            "The wind speed is " + json.wind.speed + " meter/second. <br>" + 
            "The sunrise time is " + sunrise + " and the sunset time is " + sunset +  
            "<br>The pressure is " + json.main.pressure + " hPa and humidity is " + json.main.humidity + "%. <br>The overall weather is " + weather + 
            "<br>The visibility is " + visibility ;
        }
    };
    xhr.send(null);
}
